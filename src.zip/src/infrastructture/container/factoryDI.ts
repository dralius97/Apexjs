import { Container } from "../../core/DI/container.js";
import { ContainerCore } from "../../core/DI/containerCore.js";
import { Midleware } from "../../core/middleware/middleware.js";
import { HttpResponseFormatter } from "../HttpResponseFormatter/index.js";
import { TYPE } from "./type.js";

const container = new ContainerCore()

container.bind(TYPE.Midleware, {
    instance: Midleware,
    singleton: true
})
container.bind(TYPE.HttpResponseFormatter, {
    instance: HttpResponseFormatter,
    singleton: true
})



Container.set(container)

export { container }