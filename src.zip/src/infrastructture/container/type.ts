export const TYPE = {
    Midleware: Symbol.for('Midleware'),
    HttpResponseFormatter: Symbol.for('HttpResponseFormatter') 
}