import { Request, Response } from "express-serve-static-core";
import { HttpHandler, HttpRequest, HttpResponse } from "../../../../domain/http/http.js";
import { Midleware } from "../../../../core/middleware/middleware.js";
import { HttpResponseFormatter } from "../../../../infrastructture/HttpResponseFormatter/index.js";
import { Left } from "../../../../domain/signal/railway.js";
import { Inject } from "../../../../core/DI/decorator.js";
import { TYPE } from "../../../../infrastructture/container/type.js";

export class ExpressAdapter {
    @Inject(TYPE.Midleware) private middlware!: Midleware
    @Inject(TYPE.HttpResponseFormatter) private httpResponseFormatter!: HttpResponseFormatter
    
    public call = (mdw: string, fn: HttpHandler) => async ( req: Request, res: Response )  => {
        const [httpRequest, httpResponse] = this.ctx( req, res )
        try {
            const result = await this.warp( mdw, fn )( httpRequest,httpResponse )
            if(result instanceof Left) return this.httpResponseFormatter.sendError( result, httpResponse );
            return this.httpResponseFormatter.sendResponse( result, httpResponse )
        } catch ( error ) {
            return this.httpResponseFormatter.sendError( error, httpResponse );
        }
    }
    private ctx( req: Request, res: Response ): [HttpRequest, HttpResponse] {
        const httpResponse: HttpResponse = {
            json( data ) {
                return res.json( data )
            },
            send( data ) {
                return res.send( data )
            },
            setHeader( name, value ) {
                return res.setHeader( name, value )
            },
            status( code ) {
                res.status( code )
                return this
            },
            setLocals( key, value ) {
                res.locals[ key ] = value
            },
            getLocals( key ) {
                return res.locals[ key ]
            },
        }
        const httpRequest: HttpRequest = {
            headers: req.headers as Record<string, string> | string[],
            method: req.method,
            path: req.path,
            body: req.body,
            params: req.params,
            query: req.query as Record<string, string>,
        }
        return [httpRequest, httpResponse] 
    }   
    private warp = ( mdw:string, fn:HttpHandler ) => async ( req: HttpRequest, res: HttpResponse ) => {
        const result = await this.middlware.execute( mdw )( req, res )
        if(result instanceof Left) return result
        return await fn( req, res )
    }
}