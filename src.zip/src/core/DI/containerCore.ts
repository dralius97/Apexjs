import { Identifier, Provider } from "./type.js";


export class ContainerCore{
    private registry = new Map<Identifier, Provider<unknown>>();
    private singleton = new Map<Identifier, unknown>();

    public bind<T>(key: Identifier, provider: Provider<T>){
        this.registry.set(key, provider)
    }
    public resolve(key:Identifier){
        if(!this.registry.has(key)) throw new Error(`provider not found: ${String(key)}`)
        const prov = this.registry.get(key)
        if(prov!.singleton && this.singleton.has(key)) return this.singleton.get(key)
        

        const instance = new (prov!.instance as { new (): unknown })()
        if(prov!.singleton) this.singleton.set(key, instance)
        return instance
    }
}

