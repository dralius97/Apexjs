import { HttpHandler, HttpRequest, HttpResponse } from "../../domain/http/http.js"
import { Left, Right } from "../../domain/signal/railway.js"

export class Midleware {
    private midleware: Map<string, Function[]>
    constructor(){
        this.midleware = new Map()
    }
    add(key:string, fnChain: HttpHandler[]){
        this.midleware.set(key, fnChain)
    }
    execute = (key: string) => async (req:HttpRequest,res:HttpResponse): Promise<Right<unknown> | Left | void> => {
        if(!this.midleware.has(key)) return
        const md = this.midleware.get(key)
        let result: Right<unknown> | Left = new Right('mdw pass')
        for (const fn of md!) {
            result = await fn(req,res)
            if(result instanceof Left){
                break
            }
        }
        return result
    }
}

